<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Biodata</title>
        <link rel="stylesheet" href="style2.css">
        <link rel="icon" href="img/logo-icon.ico">
    </head>
<body>
    <div class="main">
        <div class="img"></div>
        <h1>Rangga Wijaya</h1>
        <div class="text">Mahasiswa dari <strong>Unmul, Samarinda</strong></div>
        <p>Halo,Selamat datang di halamaan website saya,Umur saya 19 tahun, Asal saya dari Tenggarong dan
          hobi saya bermain basket. Saya sedang belajar mengenai Website Development.
        </p>
        <ul>
            <li><a href=""><img src="img/instagram.png" width="25px" height="25px"></a></li>
            <li><a href=""><img src="img/whatsapp.png" width="25px" height="25px"></a></li>
            <li><a href=""><img src="img/facebook.png" width="25px" height="25px"></a></li>
            <li><a href=""><img src="img/twitter.png" width="25px" height="25px"></a></li>
            <li><a href="index.php"><img src="img/logo-icon.png" width="25px" height="25px"></a></li>
        </ul>
    </div>
</body>
</html>